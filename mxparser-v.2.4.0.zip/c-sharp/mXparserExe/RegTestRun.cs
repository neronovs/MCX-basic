﻿using System;
using org.mariuszgromada.math.mxparser.regressiontesting;
namespace mXparserExe
{
    class RegTestRun
    {
        public static void Main(String[] args)
        {
			RegTestExpressionV2.Start();
			//PerformanceTests.Start();
			//RegTestExpressionAPI.Start();
			//RegTestSyntax.Start();
		}
    }
}
