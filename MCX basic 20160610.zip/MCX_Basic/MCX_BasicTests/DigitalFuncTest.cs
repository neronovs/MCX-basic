﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MCX_Basic;

namespace MCX_BasicTests
{
    [TestClass]
    public class DigitalFuncTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            DigitalFunc df = new DigitalFunc();
            Assert.IsTrue(df.isMath("abs"));
            Assert.AreEqual(3, df.returnMathResult("sqr(9)"));

        }
    }
}
